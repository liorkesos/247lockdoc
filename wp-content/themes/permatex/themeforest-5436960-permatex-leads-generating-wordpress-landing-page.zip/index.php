<?php
/*
 * This is NOT the Permatex theme.
 * You've uploaded the wrong ZIP file. Please upload only permatex.zip
 */